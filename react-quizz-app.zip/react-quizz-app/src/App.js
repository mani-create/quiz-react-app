import React from 'react';
import './App.css';
import Quiz from './components/QuizMain';

function App() {
  return (
    <div className="App">
      <Quiz />
    </div>
  );
}

export default App;
